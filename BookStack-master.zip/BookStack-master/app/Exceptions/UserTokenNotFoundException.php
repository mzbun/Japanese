<?php namespace BookStack\Exceptions;

class UserTokenNotFoundException extends \Exception
{

}
