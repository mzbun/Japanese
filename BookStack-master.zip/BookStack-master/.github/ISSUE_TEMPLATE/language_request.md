---
name: Language Request
about: Request a new language to be added to Crowdin for you to translate

---

### Language To Add

_Specify here the language you want to add._

----

_This issue template is to request a new language be added to our [Crowdin translation management project](https://crowdin.com/project/bookstack). Please don't use this template to request a new language that you are not prepared to provide translations for._   