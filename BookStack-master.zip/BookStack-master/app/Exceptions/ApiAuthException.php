<?php

namespace BookStack\Exceptions;

class ApiAuthException extends UnauthorizedException {

}