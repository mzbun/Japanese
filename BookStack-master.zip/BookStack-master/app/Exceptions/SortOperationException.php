<?php namespace BookStack\Exceptions;

use Exception;

class SortOperationException extends Exception
{

}
